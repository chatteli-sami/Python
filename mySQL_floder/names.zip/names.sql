SELECT * FROM names.name;
SELECT first_names from name;
insert into name(first_names) values ('sami');
insert into name(first_names) values ('sami', 'ninjas');
update name set first_names='itachi' where id=1;
delete from name where id=1;
